package amazonnewform.usersteps;

import amazonnewform.pages.AmazonProductDetailsPage;

public class AmazonProductDetailsUserSteps {

    private AmazonProductDetailsPage amazonProductDetailsPage;
}
