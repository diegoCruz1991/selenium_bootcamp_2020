package amazonnewform.usersteps;

import amazonnewform.pages.AmazonResultsPage;

public class AmazonResultsPageUserSteps {

    private AmazonResultsPage amazonResultsPage;
}
