package amazonnewform.pageobjects.header;

import amazonnewform.pageobjects.AmazonBasePageObject;
import org.openqa.selenium.WebDriver;

public class AmazonAuthenticationMenuPageObject extends AmazonBasePageObject {

    public AmazonAuthenticationMenuPageObject(WebDriver driver, String baseURL) {
        super(driver, baseURL);
    }
}
