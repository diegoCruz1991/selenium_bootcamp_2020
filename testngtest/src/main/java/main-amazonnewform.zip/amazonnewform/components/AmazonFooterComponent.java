package amazonnewform.components;

import org.openqa.selenium.WebDriver;

public class AmazonFooterComponent {

    public AmazonFooterComponent(WebDriver driver) {
    }

}
