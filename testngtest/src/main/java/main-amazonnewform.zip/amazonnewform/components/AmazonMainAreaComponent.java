package amazonnewform.components;

import org.openqa.selenium.WebDriver;

public class AmazonMainAreaComponent {

    public AmazonMainAreaComponent(WebDriver driver) {
    }
}
