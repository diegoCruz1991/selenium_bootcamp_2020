package amazonnewform.pages;

import org.openqa.selenium.WebDriver;

public class AmazonResultsPage extends AmazonBasePage {

    public AmazonResultsPage(WebDriver driver) {
        super(driver);
    }
}
