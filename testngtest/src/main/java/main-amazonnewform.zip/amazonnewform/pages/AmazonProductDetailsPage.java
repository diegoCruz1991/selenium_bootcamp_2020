package amazonnewform.pages;

import org.openqa.selenium.WebDriver;

public class AmazonProductDetailsPage extends AmazonBasePage {

    public AmazonProductDetailsPage(WebDriver driver) {
        super(driver);
    }
}
