package amazonnewform.pages;

import org.openqa.selenium.WebDriver;

public class AmazonHomePage extends AmazonBasePage {

    public AmazonHomePage(WebDriver driver) {
        super(driver);
    }
}
